package produto.model;


public class Produto {
    
        
    private String nomeProduto;
    private String descProduto;
    private int codProduto;
    private double valorCompraProduto;
    private double valorVendaProduto;
    private String categoriaProduto;
    private int quantidadeProduto;
    
    
    public Produto(String nomeProduto,String descProduto,int codProduto,double valorCompraProduto,double valorVendaProduto, String categoriaProduto, int quantidadeProduto){
        this.nomeProduto = nomeProduto;
        this.descProduto = descProduto;
        this.codProduto = codProduto;
        this.valorCompraProduto = valorCompraProduto;
        this.valorVendaProduto = valorVendaProduto;
        this.categoriaProduto = categoriaProduto;
        this. quantidadeProduto = quantidadeProduto;
    }
    
    public Produto() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public String getDescProduto() {
        return descProduto;
    }

    public void setDescProduto(String descProduto) {
        this.descProduto = descProduto;
    }

    public int getCodProduto() {
        return codProduto;
    }

    public double getValorCompraProduto() {
        return valorCompraProduto;
    }

    public void setValorCompraProduto(double valorCompraProduto) {
        this.valorCompraProduto = valorCompraProduto;
    }

    public double getValorVendaProduto() {
        return valorVendaProduto;
    }

    public void setValorVendaProduto(double valorVendaProduto) {
        this.valorVendaProduto = valorVendaProduto;
    }

    public String getCategoriaProduto() {
        return categoriaProduto;
    }

    public void setCategoriaProduto(String categoriaProduto) {
        this.categoriaProduto = categoriaProduto;
    }

    public int getQuantidadeProduto() {
        return quantidadeProduto;
    }

    public void setQuantidadeProduto(int quantidadeProduto) {
        this.quantidadeProduto = quantidadeProduto;
    }

    
    
   

}