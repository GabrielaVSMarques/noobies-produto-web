package produto.dao;


public class ProdutoDAO {
    public void incluirProduto(Produto produto){
        {               
        //Abrir conexao e deixa ela null
        PreparedStatement stmt = null;
        Connection conn = null;
        
        //Preparar string sql
        String sql = "INSERT INTO DB_LOJA_NOOBIES.TB_PRODUTOS (NOME_CATEGORIA, NOME_PRODUTO, DESCRICAO, "
                + "VALOR_COMPRA, VALOR_VENDA, QUANTIDADE)"
                + "VALUES (?, ?, ?, ?, ?, ?)";
        
        //Obten conexão para SQL workbench
        try 
        {
            conn = obterConexao();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, produto.getCategoriaProduto());
            stmt.setString(2, produto.getNomeProduto());
            stmt.setFloat(3, produto.getDescricao());
            stmt.setFloat(4, produto.getValorVendaProduto());
            stmt.setInt(5, produto.getQuantidadeProduto());         
            // 2) Executar SQL
            stmt.executeUpdate();
        } 
        catch (SQLException ex) 
        {
            System.out.println("Não foi possível executar.");
        } 
        catch (ClassNotFoundException ex) 
        {
            System.out.println("Não foi possível executar.");
        } finally 
        {
            if (stmt != null) 
            {
                try 
                {
                    stmt.close();
                } 
                catch (SQLException ex) 
                {
                    System.out.println("Erro ao fechar stmt.");
                }
            }
            if (conn != null) 
            {
                try 
                {
                    conn.close();
                } 
                catch (SQLException ex) 
                {
                    System.out.println("Erro ao fechar conn.");
                }
            }
        }
    }
    public void excluirProduto(){
        
    }
    public void editarProduto(){
        
    }
    public void consultarProduto(){
        
    }
}
